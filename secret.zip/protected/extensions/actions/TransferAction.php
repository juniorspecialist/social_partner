<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Саня
 * Date: 29.05.13
 * Time: 21:53
 * To change this template use File | Settings | File Templates.
 */
class TransferAction extends CAction {

    public function run()
    {
        $model = new TransferModel();

        if(isset($_POST['TransferModel'])){
          $model->attributes =$_POST['TransferModel'];
          if($model->validate()){
              //записываем операцию пополнения баланса юзера
              $connection=Yii::app()->db; // так можно сделать, если в конфигурации описан компонент соединения "db"
              $command=$connection->createCommand('UPDATE {{partner}} SET balance=balance+:suma WHERE id=:id');
              $command->bindValue(':id', $model->to_partner, PDO::PARAM_INT );
              $command->bindValue(':suma', $model->sum_transfer, PDO::PARAM_INT );
              $command->execute();

              //списываем с баланса юзера, который переводит бабло
              $query = $connection->createCommand('UPDATE {{partner}} SET balance=balance-:suma WHERE id=:id');
              $query->bindValue(':id', Yii::app()->user->id, PDO::PARAM_INT );
              $query->bindValue(':suma', $model->sum_transfer, PDO::PARAM_INT );
              $query->execute();


              // запишим операцию перевода в операции с балансом пользователя
              $account = new HistoryAccount();
              // тии операции
              $account->type_operation = HistoryAccount::TYPE_PRIHOD;
              // получатель бонуса
              $account->partner_id = $model->to_partner;
              //отправитель
              $account->bonus_sender = Yii::app()->user->id;
              //назначение операции - платежа
              $account->destination = HistoryAccount::DESTIONATION_TRANSFER;
              // сумма платежа в истории платежей
              $account->bonuse = $model->sum_transfer;
              $account->save();

              // теперь спишим с баланса тек. юзера сумму перевода
              $transfer = new HistoryAccount();
              $transfer->type_operation = HistoryAccount::TYPE_RASHOD;
             // получатель бонуса
              $account->partner_id = $model->to_partner;
              //отправитель
              $account->bonus_sender = Yii::app()->user->id;
              //назначение операции - платежа
              $account->destination = HistoryAccount::DESTIONATION_TRANSFER;
              // сумма платежа в истории платежей
              $account->bonuse = $model->sum_transfer;
              $account->save();
          }
        }

        $this->getController()->render('transfer', array(
              'model'=>$model,
          )
        );
    }
      /**
       * @return CActiveRecord
       */
      protected function getModel()
      {
          return CActiveRecord::model($this->modelName);
      }
}