<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Саня
 * Date: 29.05.13
 * Time: 21:26
 * To change this template use File | Settings | File Templates.
 */

/*
 * перевод средств между пользователя системы
 */
class TransferModel extends CFormModel {

    public $from_partner;
    public $to_partner;
    public $sum_transfer;

    public function rules()
   	{
   		return array(
            array('sum_transfer, to_partner', 'required' ),
            array('sum_transfer, to_partner', 'numerical', 'integerOnly'=>true),
            array('from_partner', 'default','value'=>Yii::app()->user->id),
            array('to_partner', 'issetPartner'),
            array('sum_transfer', 'checkBalance'),
   		);
   	}

    /*
     * проверяем, существует ли партнёр по указанному ID в системе
     */
    public function issetPartner(){
        if(!$this->hasErrors()){
            $connection=Yii::app()->db; // так можно сделать, если в конфигурации описан компонент соединения "db"
            $command=$connection->createCommand('SELECT id FROM {{partner}} WHERE id=:id');
            $command->bindParam(':id', $this->to_partner, PDO::PARAM_INT );
            $find = $command->queryRow();

            if(empty($find)){
                $this->addError('to_partner', 'Указанный партнёр не найден в системе');
            }
        }
    }

    /*
     * проверим баланс текущего юзера на наличие нужной суммы для пеервода
     */
    public function checkBalance(){
        if(!$this->hasErrors()){
            $balance = Partner::getBalance(Yii::app()->user->id);
            if($balance<$this->sum_transfer){
                $this->addError('sum_transfer', 'Сумма перевода больше чем ваш баланс');
            }
        }
    }

    public function attributeLabels()
   	{
   		return array(
   			'sum_transfer' => 'Сумма перевода',
   			'to_partner' => 'ID получателя перевода',
   			'from_partner' => 'ID отправителя бонуса',
   		);
   	}
}