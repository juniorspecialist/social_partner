<?php
/**
 * Created by JetBrains PhpStorm.
 * User: artem
 * Date: 07.05.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */

class FinanceController extends BaseAdminController {

    public function actions(){
        return array(
           /*
             * перевод денежных средств другим пользователям системы
             */
            'transfer'=>array(
                'class'=>'ext.actions.TransferAction',
            )
        );
    }

    public function actionIndex(){

        $this->render('index');
    }

    /*
     * история счёта
     */
    public function actionHistory(){

        $model = new HistoryAccount();

        //$criteria = new CDbCriteria;

        //$criteria->condition = 'partner_id='.Yii::app()->user->id.' OR bonus_sender='.Yii::app()->user->id;

        $dataProvider = new CActiveDataProvider('HistoryAccount', array(
            //'criteria'=>$criteria,
            'sort'=>array(
                'defaultOrder'=>'create_at DESC',
            ),
            'pagination'=>array(
                'pageSize'=>100,
            ),
        ));

        $this->render('history', array(
            'dataProvider'=>$dataProvider,
            'model'=>$model,
        ));
    }

    /*
     * ввод наличных средств
     */
    public function actionInputMoney(){

        if(isset($_POST['sum'])){

            for($i=0;$i<count($_POST['sum']);$i++){
                // сумма
                $row_sum = $_POST['sum'][$i];

                //ID партнёра
                $row_partner = $_POST['id'][$i];

                $model = new InputCashMoney();
                $model->partner_id = $row_partner;
                $model->sum = $row_sum;
                if($model->validate()){

                    //фиксируем операцию пополнения баланса
                    $sql = 'UPDATE {{partner}} SET balance=balance+'.$model->sum.' WHERE id='.$model->partner_id;
                    Yii::app()->db->createCommand($sql)->execute();

                    //запишим в лог пополнение баланса у юзера
                    $account = new HistoryAccount();
                    $account->type_operation = HistoryAccount::TYPE_PRIHOD;
                    $account->bonuse = $model->sum;
                    $account->bonus_sender = Yii::app()->config->get('ADMIN.ACCOUNT');
                    $account->partner_id = $model->partner_id;
                    $account->destination = HistoryAccount::DESTIONATION_TRANSFER;
                    $account->save();
                }
                Yii::app()->user->setFlash('inputmoney','Пополнение баласа, у выбранных пользователей, прошло успешно.');
                $this->refresh();
            }
        }


        $this->render('input_money');
    }

    /*
     *Заявки на вывод средств, заполненные пользователем, падают в аккаунт админа
     */
    public function actionOutputmoney(){

        $model = new Cashout();

         $dataProvider = new CActiveDataProvider('Cashout', array(
             //'criteria'=>$criteria,
             'sort'=>array(
                 'defaultOrder'=>'t.create_at DESC',
             ),
             'pagination'=>array(
                 'pageSize'=>100,
             ),
         ));

         $this->render('output_money', array(
             'dataProvider'=>$dataProvider,
             'model'=>$model,
         ));
    }

    /*
     * изменение статуса заявки на вывод средств
     */
    public function actionToggle($id)
    {
        if(!Yii::app()->request->isAjaxRequest){
            throw new CHttpException(400,'Не корректный запрос');
        }

        $model = Cashout::model()->findByPk($id);

        // ПОЛУЧАЕМ НА ДАННЫЙ МОМЕНТ  баланс юзера, хватает ли ему на текущ. момент выполнить заявку ан вывод средств
        $balance = Partner::getBalance($model->partner_id);
        if($model->sum_cash>$balance){
            throw new CHttpException(400,'У пользователя, создавшего заявку, нет на балансе необходимой суммы денег для вывода');
        }else{
            // установим новый статус у заявки на вывод денег
            $model->status = Cashout::STATUS_ACCEPT;
            $model->save();

            // СПИСЫВАЕМ С БАЛАнса юзера сумму - котор. он указал в заявке
            $sql = 'UPDATE {{partner}} SET balance=balance-:suma WHERE id=:id';
            $connect = Yii::app()->db;
            $query = $connect->createCommand($sql);
            $query->bindValue(':id', $model->partner_id, PDO::PARAM_INT);
            $query->bindValue(':suma', $model->sum_cash, PDO::PARAM_INT);
            $query->execute();

            // теперь запишим в операции по счету - списание с баланса
            $account = new HistoryAccount();
            $account->type_operation = HistoryAccount::TYPE_RASHOD;
            $account->bonuse = $model->sum_cash;
            $account->bonus_sender = $model->partner_id;
            $account->partner_id = $model->partner_id;
            $account->destination = HistoryAccount::DESTIONATION_CASHOUT;
            $account->save();
        }

        if (!Yii::app()->request->isAjaxRequest)
            $this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
    }
}