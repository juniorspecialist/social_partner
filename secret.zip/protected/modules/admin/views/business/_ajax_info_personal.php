<?php
/**
 * Created by JetBrains PhpStorm.
 * User: artem
 * Date: 20.05.13
 * Time: 14:30
 * To change this template use File | Settings | File Templates.
 */
?>
<strong>ID пользователя:</strong><?=$model->id?><br>
<strong>ФИО пользователя:</strong><?=$model->fio?><br>
<strong>Верифицированный телефонный номер:</strong><?=$model->phone?><br>
<strong>E-mail пользователя:</strong><?=$model->email?><br>